const Razorpay = require('razorpay');
const Order = require("../models/orderModel");

// Initialize Razorpay instance with your credentials
const razorpayInstance = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,   // You can get this from your Razorpay dashboard
  key_secret: process.env.RAZORPAY_KEY_SECRET, // You can get this from your Razorpay dashboard
});

// Create Razorpay Order and save it in the database
const createOrder = async (req, res) => {
  try {
    const { items, shippingAddress, totalAmount } = req.body;

    console.log("Body received:", req.body); // Debug log

    if (!items || items.length === 0) {
      return res.status(400).json({ message: "No order items provided" });
    }

    // Create a new order in the database (for internal tracking)
    const order = new Order({
      user: req.user._id, // Comes from auth middleware
      items,
      shippingAddress,
      totalAmount,
      paymentStatus: "Pending",
    });

    const savedOrder = await order.save();

    // Now, create the Razorpay order
    const options = {
      amount: totalAmount * 100, // Razorpay requires the amount in paise (1 INR = 100 paise)
      currency: "INR",  // You can set it to your preferred currency
      receipt: savedOrder._id.toString(), // Receipt ID, you can use the order ID here
    };

    const razorpayOrder = await razorpayInstance.orders.create(options);

    if (!razorpayOrder) {
      return res.status(500).json({ message: "Payment creation failed" });
    }

    // Send Razorpay order and key_id to frontend
    res.status(201).json({
      message: "Order created successfully",
      order: savedOrder,
      razorpayOrder,
      key_id: razorpayInstance.key_id,  // Frontend needs this to load Razorpay modal
    });
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = { createOrder };

// const Order = require("../models/orderModel");

// const createOrder = async (req, res) => {
//   try {
//     const { items, shippingAddress, totalAmount } = req.body;

//     console.log("Body received:", req.body); // Debug log

//     if (!items || items.length === 0) {
//       return res.status(400).json({ message: "No order items provided" });
//     }

//     const order = new Order({
//       user: req.user._id, // Comes from auth middleware
//       items,
//       shippingAddress,
//       totalAmount,
//       paymentStatus: "Pending",
//     });

//     const savedOrder = await order.save();

//     res.status(201).json({
//       message: "Order created successfully",
//       order: savedOrder,
//     });
//   } catch (error) {
//     console.error("Error creating order:", error);
//     res.status(500).json({ message: "Server error" });
//   }
// };

// module.exports = { createOrder };
